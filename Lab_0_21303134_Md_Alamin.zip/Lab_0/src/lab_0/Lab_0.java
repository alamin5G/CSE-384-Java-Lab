package lab_0;

/**
 *
 * @author Md. Alamin
 * @id 21303134
 * @section A
 * @semester - Fall-2024
 */
public class Lab_0 {

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hello, World");
    }
    
}
