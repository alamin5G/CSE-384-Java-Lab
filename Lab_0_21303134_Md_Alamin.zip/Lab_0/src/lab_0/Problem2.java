package lab_0;

/**
 *
 * @author Md. Alamin
 * @id 21303134
 * @section A
 * @semester - Fall-2024
 */
 public class Problem2 {
    public static void main(String[] args){
       /*
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        System.out.println("Hello, World");
        */
       
       for(int i = 1; i<=10; i++){
           System.out.println("Hello, World");
       }
        
    }
}
