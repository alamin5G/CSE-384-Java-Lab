
public class SquareRoot {

    public static void main(String args[]) {
        double x = 16;
        double y;
        y = Math.sqrt(x);
        System.out.println("Y= " + y);
    }
}
