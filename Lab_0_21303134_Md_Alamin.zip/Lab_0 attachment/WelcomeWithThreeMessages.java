
public class WelcomeWithThreeMessages {

    public static void main(String[] args) {
        System.out.println("Programming is Fun!");
        System.out.println("Fundamentals First!");
        System.out.println("Problem Driven");
    }
}
