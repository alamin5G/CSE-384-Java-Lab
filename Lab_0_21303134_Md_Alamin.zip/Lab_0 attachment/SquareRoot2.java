
public class SquareRoot2 {

    public static void main(String args[]) {
        final double x = 5;
        x = Math.sqrt(x); //showing error due to set the final keyword before the double x = 5;
        System.out.println("X= " + x);
    }

}
