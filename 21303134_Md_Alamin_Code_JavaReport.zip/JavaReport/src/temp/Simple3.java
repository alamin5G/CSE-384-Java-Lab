/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package temp;

/**
 *
 * @author Student
 */
class Simple3{
	
	public static void main (String args[]){
		int LIMIT=5;
		try{	
			int a[]=new int [5];
			a[4]=50/LIMIT;
		}catch(Exception e){System.out.println("Common Task Completed"); }
                
			
		System.out.println(" Rest Of the code");
	}
} 