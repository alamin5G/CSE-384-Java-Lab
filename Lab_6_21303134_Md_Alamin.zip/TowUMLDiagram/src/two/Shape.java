/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package two;

/**
 *
 * @author alami
 */
public class Shape {
    protected double area;

    public double getArea() {
        return area;
    }
}


