<?php include 'header.php'; 
    
?>

<h1>Contact Us</h1>
<p>
    Have questions or feedback? Reach out to us:
</p>
<ul>
    <li>Email: support@gameleadersystem.com</li>
    <li>Phone: +1 234 567 890</li>
    <li>Address: 123 Quiz Lane, Knowledge City, World</li>
</ul>
<?php include 'footer.php'; ?>
