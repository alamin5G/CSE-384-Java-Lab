<?php include 'header.php'; ?>
<h1>About Us</h1>
<p>
    Welcome to the Game Leaderboard System. This platform allows users to challenge themselves with quiz games and compete with others on the leaderboard. Administrators can manage the quiz database, ensuring fresh and exciting questions for players.
</p>
<?php include 'footer.php'; ?>
