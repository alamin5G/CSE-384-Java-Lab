/**
 * @(#)ClassA.java
 *
 *
 * @author 
 * @version 1.00 2024/10/31
 */

package package1;
public class ClassA {
 
    public static void displayA(){
        System.out.println("Class A");
    }
    
   
    
}