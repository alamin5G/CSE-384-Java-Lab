/**
 * @(#)Text1.java
 *
 *
 * @author 
 * @version 1.00 2024/10/31
 */

import package1.ClassA;

public class PackageTest {

  public static void main (String[] args) {
  	ClassA obj1 = new ClassA( );
  	obj1.displayA();
  }
    
}